#!/usr/bin/env python3
"""Read-only static structural recovery of stage-1 Luraph payload tail.
NEVER runs Luau, embedded payload, network, or game APIs.
Offsets refer to zero-based 860,012-byte Base85-decoded buffer.
"""
from pathlib import Path
from collections import Counter
import csv, json, hashlib, struct, zipfile
ROOT=Path('/mnt/data')
b=(ROOT/'enchantments_v37_VM_payload_stage1.bin').read_bytes()
assert len(b)==860012
assert hashlib.sha256(b).hexdigest()=='b21e07864bd3a053480a14e0509009a7ec26e6939d9cd2bab0dd65bee88b7319'
TAIL=216222; POOL_HDR=216617; POOL_VALUES=216620; POOL_END=298298; PROTO_HDR_END=298300; END_PROTOS=860007; END_ROOT=860009
class Reader:
    def __init__(self, start,stop=None):self.p=start;self.end=stop or len(b)
    def data(self,n):
        if n<0 or self.p+n>self.end:raise ValueError(f'out of bounds offset {self.p} n {n}')
        start=self.p;self.p+=n;return b[start:self.p]
    def u8(self):return self.data(1)[0]
    def u(self,n,signed=False):return int.from_bytes(self.data(n),'little',signed=signed)
    def varint(self):
        v=0
        for sh in range(0,70,7):
            a=self.u8(); v+=(a&127)<<sh
            if a<128:return v
        raise ValueError(f'invalid varint offset {self.p}')

# Preserve exact previously-unparsed bytes, not a newly synthesized executable.
sub=b[TAIL:]; (ROOT/'enchantments_v37_잔여643790_원본바이트.bin').write_bytes(sub)
(ROOT/'enchantments_v37_프리앰블395_원본.bin').write_bytes(b[TAIL:POOL_HDR])
(ROOT/'enchantments_v37_프리앰블_앞69.bin').write_bytes(b[TAIL:216291])
(ROOT/'enchantments_v37_프리앰블_뒤70.bin').write_bytes(b[216547:POOL_HDR])
# Plausible 64 x signed LE 32-bit values; their meanings are NOT established.
words=struct.unpack_from('<64i',b,216291)
with (ROOT/'enchantments_v37_프리앰블_64정수_후보.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['index','offset_0based','i32_le_value','semantic_status'])
    for j,x in enumerate(words):w.writerow([j+1,216291+j*4,x,'unverified'])

r=Reader(POOL_HDR,POOL_END)
raw_constants=r.varint();count=raw_constants-1367;flag=r.u8()
assert raw_constants==8943 and count==7576 and flag==3 and r.p==POOL_VALUES
pool_types=Counter();str_count=0;pool=[]
for idx in range(1,count+1):
    off=r.p;tag=r.u8();content=b'';num=None
    if tag<=29:
        kind='byte_string';n=r.varint();content=r.data(n);str_count+=1
    elif tag<=53: kind='u16';num=r.u(2)
    elif tag==54:kind='f64';num=struct.unpack('<d',r.data(8))[0]
    elif tag<=60:kind='runtime_reference_true_marker';num=True
    elif tag<100:kind='boolean_false';num=False
    elif tag==100:kind='i64';num=r.u(8,True)
    elif tag<=107:kind='boolean_false';num=False
    elif tag<=115:kind='u32';num=r.u(4)
    elif tag==206:kind='u8';num=r.u(1)
    elif tag<=207:kind='i16';num=r.u(2,True)
    elif tag<=213:kind='neg_u8';num=-r.u(1)
    elif tag<=225:kind='neg_u32';num=-r.u(4)
    else:kind='neg_i32';num=-r.u(4,True)
    pool_types[kind]+=1
    pool.append((idx,off,r.p,tag,kind,(content.hex() if content else repr(num)),len(content),content[:64].hex() if content else ''))
assert r.p==POOL_END
with (ROOT/'enchantments_v37_추가상수7576.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['index','byte_start','byte_end','tag','raw_value_type','value_hex_or_repr','string_bytes_length','string_prefix64_hex']);w.writerows(pool)
# Note: String data is BYTE-CONTENT, not assumed readable/decrypted Luau text.

r=Reader(POOL_END,END_PROTOS)
raw_proto_count=r.varint();n_proto=raw_proto_count-8816
assert raw_proto_count==9740 and n_proto==924 and r.p==PROTO_HDR_END
proto_tag_counts=Counter();opcode_freq=Counter();link_counts=Counter();mode7_refs=Counter();badrefs=[];instruction_count=0
proto_rows=[]; op_csv=ROOT/'enchantments_v37_추가VM명령89983.ndjson'
links_file=ROOT/'enchantments_v37_추가참조_색인.csv'
root_ins=[];tag_not165=[]
with op_csv.open('w',encoding='utf-8') as ins_f, links_file.open('w',newline='',encoding='utf-8-sig') as link_f:
    link_w=csv.writer(link_f);link_w.writerow(['prototype','link_index','encoded_key','mode','index_component'])
    for proto_id in range(1,n_proto+1):
        st=r.p;tag=r.varint();frame=r.varint();raw_n=r.varint();ninstr=raw_n-75528
        assert 0<=tag<=219 and 0<=ninstr<=100000 and frame<10000, (proto_id,st,tag,frame,ninstr)
        proto_tag_counts[tag]+=1
        if tag!=165:tag_not165.append((proto_id,tag))
        for pc in range(1,ninstr+1):
            off=r.p;values=[r.varint() for _ in range(4)];op=values[3]
            opcode_freq[op]+=1;instruction_count+=1
            fields=[]
            for name,x in zip(('b','p','n'),values[:3]):
                mode=x%8;index=x//8
                fields.append({'kind':name,'value':index,'mode':mode})
                if mode==7:
                    mode7_refs[name]+=1
                    if not (1<=index<=count):badrefs.append((proto_id,pc,name,index))
            rec={'prototype':proto_id,'pc':pc,'byte_offset':off,'vm_dispatch_code_not_native_luau':op,'operands':fields,'raw_varints':values}
            ins_f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
            if proto_id==497:root_ins.append(rec)
        nlinks=r.varint()
        assert 0<=nlinks<100000
        link_counts['links']+=nlinks
        for ix in range(1,nlinks+1):
            key=r.varint();link_w.writerow([proto_id,ix,key,key%4,key//4]);link_counts['unique_links_'+str(key)]+=0
        proto_rows.append((proto_id,st,r.p,tag,frame,ninstr,nlinks))
assert r.p==END_PROTOS, (r.p,END_PROTOS)
assert instruction_count==89983
assert len(proto_rows)==924
root_key=Reader(END_PROTOS,END_ROOT).varint()
assert root_key==497 and b[END_ROOT:]==b'\x00'*3
assert not badrefs, f'invalid refs: {badrefs[:4]}'
assert sorted(proto_tag_counts)==list(range(220)), sorted(set(range(220))-set(proto_tag_counts))
assert proto_tag_counts[165]==705
assert sorted(x for x in opcode_freq if x<=255)==list(range(256))
assert sorted(x for x in opcode_freq if x>255)==[4503599627370495]
assert all(v==1 for k,v in proto_tag_counts.items() if k!=165)
with (ROOT/'enchantments_v37_추가프로토타입924.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['prototype_index','start_offset_0based','end_offset_exclusive','tag','frame','instruction_records','references']);w.writerows(proto_rows)
with (ROOT/'enchantments_v37_추가opcode_빈도.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['raw_vm_dispatch_code','frequency','is_native_luau_opcode']);w.writerows((i,c,False) for i,c in sorted(opcode_freq.items()))
with (ROOT/'enchantments_v37_루트497_추가명령읽기전용.txt').open('w',encoding='utf8') as f:
    f.write('# Root candidate 497: virtual records, NOT executable Luau code.\n')
    for rec in root_ins:
        args=' '.join(f"{i['kind']}:{i['value']}[{i['mode']}]" for i in rec['operands'])
        f.write(f"{rec['pc']:04} offset={rec['byte_offset']:06X} DISPATCH_{rec['vm_dispatch_code_not_native_luau']} {args}\n")
sections=[
('prefix_unknown_69',TAIL,216291,'raw bytes; unknown semantics'),
('signed_i32_candidate_64',216291,216547,'64 consecutive little-endian signed words; semantics unverified'),
('suffix_unknown_70',216547,POOL_HDR,'raw bytes; unknown semantics'),
('constant_count_and_flag',POOL_HDR,POOL_VALUES,'varint 8943 -> 7576; flag=3'),
('typed_constants_7576',POOL_VALUES,POOL_END,'raw typed constant records; bytes may still be encrypted'),
('prototype_count',POOL_END,PROTO_HDR_END,'varint 9740 -> 924'),
('virtual_prototype_records_924',PROTO_HDR_END,END_PROTOS,'89,983 raw instruction records and link references'),
('root_candidate',END_PROTOS,END_ROOT,'varint 497'),
('trailing_zeros',END_ROOT,len(b),'three 00 bytes')]
with (ROOT/'enchantments_v37_잔여영역_바이트맵.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['region','start_inclusive','end_exclusive','size_bytes','interpretation']);w.writerows((name,a,c,c-a,note) for name,a,c,note in sections)
assert sections[0][1]==TAIL and sections[-1][2]==len(b) and all(sections[i][2]==sections[i+1][1] for i in range(len(sections)-1))
metrics={
 'full_stage1_size':len(b),'original_previous_tail_start':TAIL,'tail_size':len(sub),
 'tail_sha256':hashlib.sha256(sub).hexdigest(),'preamble_uninterpreted_bytes':69+70,
 'preamble_i32_candidates':64,'second_pool_count':count,'pool_flag':flag,
 'second_pool_strings_raw':str_count,'second_pool_type_counts':dict(pool_types),
 'second_prototype_count':n_proto,'second_instruction_record_count':instruction_count,
 'second_link_reference_count':link_counts['links'],'vm_dispatch_id_count':len(opcode_freq),
 'dispatch_id_min':min(opcode_freq),'dispatch_id_max':max(opcode_freq),
 'dispatch_sentinel_value':4503599627370495,'dispatch_sentinel_records':opcode_freq[4503599627370495],
 'tags_distinct':len(proto_tag_counts),'tag165_count':proto_tag_counts[165],
 'other_tags_each_once':True,'root_proto_candidate':root_key,
 'root_record_count':len(root_ins),'constant_ref_mode7_counts':dict(mode7_refs),
 'constant_ref_mode7_invalid':len(badrefs),'record_area_end':r.p,
 'trailing_padding_bytes':len(b)-END_ROOT,'sections':[
  dict(region=label,start=a,end=c,length=c-a,note=note) for label,a,c,note in sections
 ]}
(ROOT/'enchantments_v37_잔여영역_검증메타.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf8')
root_details=proto_rows[root_key-1]
report=f'''# Enchantments v37 — 기존 미해석 643,790바이트의 추가 구조 복원

## 확인된 결과

이 보고서는 사용자 업로드 파일에서 파생한 `860,012`바이트 1차 Base85 해제 결과를 **실행하지 않고 읽기 전용 파싱**한 결과다. 기존 파서의 끝 오프셋 `216,222` 뒤의 **정확히 {len(sub):,}바이트** 전부를 바이트 범위별로 분리했다.

- 추가 상수풀: 시작 `{POOL_HDR:,}`에서 가변길이 정수 `8943`, 이 로더에서 사용하는 보정 `-1367`로 **7,576개**. 다음 플래그는 `3`(0이 아님). 실제 항목 `{POOL_VALUES:,}`~`{POOL_END:,}`을 파싱했으며, 별도 바이트 문자열 항목은 **{str_count:,}개**다. 문자열의 평문 복호화는 하지 않았다.
- 이어지는 프로토타입 헤더: `{POOL_END:,}`에서 가변길이 정수 `9740`, 로더 보정 `-8816`로 **924개**.
- 프로토타입 924개 모두 `{PROTO_HDR_END:,}`에서 `{END_PROTOS:,}`까지 **89,983개** 가상 명령 레코드로 완전히 순차 파싱했다. 각 명령은 4개의 가변길이 필드다.
- 가상 명령 코드 후보는 `0..255` 전부 256종이며, 별도 특수값 `4503599627370495`도 **{opcode_freq[4503599627370495]}회** 기록돼 있다. 총 서로 다른 원시 값은 {len(opcode_freq)}개다. 특수값을 Luau opcode로 간주하지 않는다.
- 프로토타입 선택 태그 `0..219` 전체가 등장. `165` 태그는 705회이고 나머지 219개는 1회씩이다.
- 모드 7의 상수 참조 {sum(mode7_refs.values()):,}건 전부 위의 7,576개 상수 인덱스 범위에 존재한다.
- 마지막 루트 후보 인덱스는 `{root_key}`. 루트 후보 #{root_key}는 태그 `{root_details[3]}`, 프레임 `{root_details[4]}`, 명령 `{root_details[5]:,}`개다.
- 마지막 3바이트는 `00 00 00`이다.

## 전체 {len(sub):,}바이트 범위 보존 및 매핑

| 이름 | 0-based 시작(포함) | 끝(제외) | 크기(바이트) | 검증 수준 |
|---|---:|---:|---:|---|
'''
for name,a,c,note in sections:report+=f'| {name} | {a:,} | {c:,} | {c-a:,} | {note} |\n'
report+=f'''

## 여전히 원본 Luau로 복구되지 않은 부분

- 시작 부근 **139바이트**(69 + 70)의 구체적 의미는 알 수 없다. 그 사이의 256바이트는 64개의 32비트 정수로 정렬되지만 그 용도를 확정할 수 없다.
- `byte_string` 항목 {str_count:,}개를 바이트 단위로 정확히 꺼냈지만, 문자열 암호화/변환 여부와 평문을 아직 검증하지 않았다.
- 89,983개 명령 레코드는 *구조적으로 분리한 원시 가상 명령*으로, 네이티브 Luau opcode, 소스 문장, 참/거짓 점프가 확정된 것은 아니다.
- 원래 변수명 및 사용자 주석 복구는 불가하다. 숨겨진 실행 로직을 재실행·재구현하지 않았으며 안전성도 검증되지 않았다.

## 검증 근거 및 재현 방법

- 이전 단계와 동일한 입력 SHA-256: `{hashlib.sha256(b).hexdigest()}`.
- 추출된 tail SHA-256: `{hashlib.sha256(sub).hexdigest()}`.
- 원본 데이터 643,790바이트 중 빠진 범위 또는 서로 겹친 범위 **0바이트**.
- 7,576개 상수 이후 정확히 프로토타입 개수 헤더 `9740`이 이어지고, 924개 프로토타입 이후 정확히 루트 후보 `497` 및 3바이트 0패딩이 이어진다.
- `recover_v37_remaining_static.py`는 Python 바이트 파서로만 동작한다. Luau VM·HTTP·게임 API 실행이 없다.

파일: `잔여643790_원본바이트.bin`, `잔여영역_바이트맵.csv`, `추가상수7576.csv`, `추가프로토타입924.csv`, `추가VM명령89983.ndjson`, `루트497_추가명령읽기전용.txt`, `프리앰블_64정수_후보.csv`.
'''
(ROOT/'enchantments_v37_잔여643790_추가복원_보고서.md').write_text(report,encoding='utf8')
# ZIP includes exact tail, relevant CSVs and independent parser, never executable decoded Lua.
files=[
 'enchantments_v37_잔여643790_원본바이트.bin',
 'enchantments_v37_프리앰블395_원본.bin',
 'enchantments_v37_프리앰블_64정수_후보.csv',
 'enchantments_v37_추가상수7576.csv',
 'enchantments_v37_추가프로토타입924.csv',
 'enchantments_v37_추가VM명령89983.ndjson',
 'enchantments_v37_추가참조_색인.csv',
 'enchantments_v37_추가opcode_빈도.csv',
 'enchantments_v37_루트497_추가명령읽기전용.txt',
 'enchantments_v37_잔여영역_바이트맵.csv',
 'enchantments_v37_잔여영역_검증메타.json',
 'enchantments_v37_잔여643790_추가복원_보고서.md',
 'recover_v37_remaining_static.py'
]
zip_path=ROOT/'enchantments_v37_잔여643790_추가구조복원_전체.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for file in files:z.write(ROOT/file,arcname=file)
with zipfile.ZipFile(zip_path,'r') as z:assert z.testzip() is None and len(z.namelist())==len(files)
assert (ROOT/'enchantments_v37_잔여643790_원본바이트.bin').read_bytes()==sub
print('SHA256 stage1',hashlib.sha256(b).hexdigest())
print('TAIL exact bytes',len(sub),'SHA256',hashlib.sha256(sub).hexdigest())
print('POOL',count,'strings',str_count,'flag',flag,'end',POOL_END)
print('PROTOTYPES',n_proto,'records',instruction_count,'tags',len(proto_tag_counts),'tag165',proto_tag_counts[165])
print('OPCODE IDs',len(opcode_freq),'normal',len([i for i in opcode_freq if i<=255]),'special sentinel records',opcode_freq[4503599627370495])
print('LINKS',link_counts['links'],'mode7 refs valid',sum(mode7_refs.values()),'bad',len(badrefs))
print('ROOT',root_key,'details',root_details)
print('COVERAGE PASS, verified non-overlapping region bytes',sum(x[2]-x[1] for x in sections),'preamble unknown semantic bytes',139,'padding',3)
print('ZIP CRC PASS',zip_path.name,zip_path.stat().st_size,'files',len(files))
